SMART RECYCLING — ENHANCED WEBSITE
==================================

HOW TO RUN
1. Extract the ZIP.
2. Open index.html in a modern browser.
3. For best results, use a simple local web server (optional).

WHAT'S INCLUDED
- Responsive page layout and shared navigation
- Light/dark theme toggle
- Settings saved in browser localStorage
- Local recycling FAQ assistant (not a live AI service)
- Eco Catch mini-game
- Five-question interactive quiz
- Gallery illustrations, About, Contact, Story and Team pages

IMPORTANT BEFORE PUBLISHING
- Replace smartrecycling@example.com in contact.html with a real project email.
- Add real team member names and credits to team.html.
- Confirm all sorting advice against the school's/local council's actual recycling rules.
- The gallery contains original SVG illustrations, not real photographs.
- The assistant is a local FAQ demo and does not use an external AI API.
- No recycling impact statistics are presented as measured facts; project goals should be labelled as targets.

The original ZIP contained only HTML files, with referenced CSS, JavaScript and image folders missing. This enhanced package supplies a complete self-contained site structure.
