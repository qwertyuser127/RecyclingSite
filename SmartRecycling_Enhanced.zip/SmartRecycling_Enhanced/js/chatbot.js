
(() => {
 const windowEl=document.querySelector('#chatWindow'),input=document.querySelector('#chatMessage');
 const rules=[
 [/battery|batteries|phone|electronics|charger/i,'Batteries and small electronics should never go in ordinary recycling or general-waste bins. Use a dedicated battery or e-waste collection point. Keep damaged batteries separate and ask a staff member for help.'],
 [/plastic bottle|bottle|plastic/i,'For an empty plastic drinks bottle: empty it, give it a quick rinse if needed, and follow the plastic/packaging label on your local school bins. Flatten it only if your collection instructions allow it.'],
 [/paper|cardboard|box/i,'Clean, dry paper and cardboard are commonly recyclable. Keep them free from food, grease and liquids. Flatten boxes to save space.'],
 [/can|tin|aluminium|metal/i,'Empty metal drink cans and clean food tins are commonly accepted in metal or packaging recycling. Check your local bin label first.'],
 [/glass|jar/i,'Glass rules vary by collection area. Use a designated glass bank or glass bin if your school provides one; do not put broken glass into ordinary mixed recycling.'],
 [/food|banana|apple|leftover/i,'Food scraps belong in a food-waste or compost collection where available. Otherwise, follow your school’s local waste instructions. Keep food out of paper and packaging recycling.'],
 [/clean|rinse|wash/i,'Empty containers first. A quick rinse is usually enough when residue would contaminate other materials; they do not need to be spotless. Let paper and cardboard stay dry.'],
 [/joke|funny/i,'Why did the recycling bin get promoted? It was great at sorting things out. ♻️'],
 [/hello|hi|hey/i,'Hello! I’m EcoMind-01. Ask me about bottles, paper, food waste, batteries or packaging.']
 ];
 function add(text,who){let b=document.createElement('div');b.className='bubble '+(who==='user'?'user':'');let small=document.createElement('small');small.textContent=who==='user'?'You':'EcoMind-01';let p=document.createElement('div');p.textContent=text;b.append(small,p);windowEl.append(b);windowEl.scrollTop=windowEl.scrollHeight}
 function send(value=input.value){let q=value.trim();if(!q)return;add(q,'user');input.value='';let hit=rules.find(([re])=>re.test(q));let answer=hit?hit[1]:'I’m a local demo assistant, so I can answer common sorting questions but I don’t connect to a live AI service. Tell me what the item is made of, whether it is clean, and what your school’s bin labels say. Local collection rules always take priority.';setTimeout(()=>add(answer),250)}
 document.querySelector('#chatSend').addEventListener('click',()=>send());input.addEventListener('keydown',e=>{if(e.key==='Enter')send()});
 document.querySelector('#chatClear').addEventListener('click',()=>{windowEl.replaceChildren();add('Chat cleared. What would you like to sort?')});
 document.querySelectorAll('.suggestions button').forEach(b=>b.addEventListener('click',()=>send(b.textContent)));
 add('Hi! I’m EcoMind-01. I can help with everyday recycling questions. What are you trying to sort?');
})();
