
(() => {
 const $=(s,r=document)=>r.querySelector(s);
 const links=[['Home','index.html'],['Our solution','solution.html'],['AI assistant','chatbot.html'],['Eco Catch','game.html'],['Quiz','quiz.html'],['Gallery','gallery.html'],['About','about.html']];
 const current=location.pathname.split('/').pop()||'index.html';
 const header=document.createElement('header');header.className='site-header';
 header.innerHTML=`<a class="skip-link" href="#main">Skip to content</a><div class="nav-wrap"><a class="brand" href="index.html"><span class="brand-mark">♻</span> Smart Recycling</a><button class="menu-btn" aria-label="Toggle navigation" aria-expanded="false">☰</button><nav class="nav-links" aria-label="Main navigation">${links.map(([n,h])=>`<a href="${h}" ${current===h?'aria-current="page"':''}>${n}</a>`).join('')}<a href="settings.html">Settings</a></nav><div class="nav-tools"><button class="icon-btn" id="themeToggle" aria-label="Toggle dark mode" title="Toggle theme">◐</button></div></div>`;
 document.body.prepend(header);
 const footer=document.createElement('footer');footer.className='site-footer';footer.innerHTML='Built to make better recycling habits easier. <a href="about.html">About this project</a> · <a href="contact.html">Contact</a>';document.body.append(footer);
 const saved=localStorage.getItem('sr-theme');if(saved==='dark'||(!saved&&matchMedia('(prefers-color-scheme: dark)').matches))document.body.classList.add('dark');
 $('#themeToggle').addEventListener('click',()=>{document.body.classList.toggle('dark');localStorage.setItem('sr-theme',document.body.classList.contains('dark')?'dark':'light')});
 const menu=$('.menu-btn'),nav=$('.nav-links');menu.addEventListener('click',()=>{let open=nav.classList.toggle('open');menu.setAttribute('aria-expanded',open);menu.textContent=open?'✕':'☰'});
 window.srToast=(msg)=>{let t=$('.toast');if(!t){t=document.createElement('div');t.className='toast';t.setAttribute('role','status');document.body.append(t)}t.textContent=msg;t.classList.add('show');clearTimeout(window._toastTimer);window._toastTimer=setTimeout(()=>t.classList.remove('show'),2500)};
})();
