
(() => {
 const c=document.querySelector('#gameCanvas'),ctx=c.getContext('2d'),scoreEl=document.querySelector('#gameScore'),livesEl=document.querySelector('#gameLives'),msg=document.querySelector('#gameMsg');
 let W=800,H=450,items=[],score=0,lives=3,running=false,last=0,spawn=0,player=400,keys={};
 function resize(){let r=c.getBoundingClientRect();let d=Math.min(devicePixelRatio||1,2);c.width=r.width*d;c.height=r.width*9/16*d;ctx.setTransform(c.width/W,0,0,c.width/W,0,0)}window.addEventListener('resize',resize);resize();
 function reset(){items=[];score=0;lives=3;player=W/2;scoreEl.textContent='Score: 0';livesEl.textContent='Lives: ♥ ♥ ♥';msg.textContent='Catch recyclable items and avoid rubbish.'}
 function start(){reset();running=true;last=performance.now();requestAnimationFrame(loop)}
 function draw(){ctx.clearRect(0,0,W,H);let g=ctx.createLinearGradient(0,0,0,H);g.addColorStop(0,'#e8f7e8');g.addColorStop(1,'#b7dfbf');ctx.fillStyle=g;ctx.fillRect(0,0,W,H);ctx.fillStyle='#9acb9f';for(let x=0;x<W;x+=80)ctx.fillRect(x,0,2,H);
 ctx.font='bold 42px sans-serif';items.forEach(i=>{ctx.fillText(i.good?'♻️':'🗑️',i.x-20,i.y+15)});ctx.font='54px sans-serif';ctx.fillText('🟩',player-28,H-45);ctx.font='16px sans-serif';ctx.fillStyle='#286044';ctx.fillText('MOVE WITH ← → OR A / D',18,28)}
 function loop(t){if(!running)return;let dt=Math.min((t-last)/16,2);last=t;spawn+=dt;if(spawn>32){spawn=0;items.push({x:35+Math.random()*(W-70),y:-20,good:Math.random()>.3,speed:2+Math.random()*2+Math.min(score/120,2)})}
 if(keys.ArrowLeft||keys.a)player-=6*dt;if(keys.ArrowRight||keys.d)player+=6*dt;player=Math.max(35,Math.min(W-35,player));
 for(let i=items.length-1;i>=0;i--){let o=items[i];o.y+=o.speed*dt;if(o.y>H-72&&o.y<H-20&&Math.abs(o.x-player)<48){if(o.good)score+=10;else lives--;items.splice(i,1);scoreEl.textContent='Score: '+score;livesEl.textContent='Lives: '+'♥ '.repeat(lives).trim();continue}if(o.y>H+20)items.splice(i,1)}
 draw();if(lives<=0){running=false;msg.textContent=`Game over! You scored ${score}. Press Start to try again.`;return}requestAnimationFrame(loop)}
 document.querySelector('#gameStart').addEventListener('click',start);document.addEventListener('keydown',e=>{keys[e.key]=true});document.addEventListener('keyup',e=>{keys[e.key]=false});
 c.addEventListener('pointermove',e=>{if(e.buttons){let r=c.getBoundingClientRect();player=(e.clientX-r.left)/r.width*W}});
 draw();
})();
